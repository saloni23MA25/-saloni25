import list1
import set2
import dict3

print(list1.append1(5))
print(set2.adds2(10))
print(dict3.add3('x', 100))