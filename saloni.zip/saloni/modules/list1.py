def append1(x):
    l = []
    l.append(x)
    return l

def extend1(l):
    return l + [1, 2, 3]

def pop():
    l = [1,2,3]
    l.pop()
    return l

def remove1(x):
    l = [1,2,x]
    l.remove(x)
    return l