def slen2(s):
    return len(s)

def adds2(x):
    s = set()
    s.add(x)
    return s

def remove2(x):
    s = {x, 2, 3}
    s.remove(x)
    return s