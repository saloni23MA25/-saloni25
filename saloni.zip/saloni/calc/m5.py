import call1

print(call1.add1(5, 3))
print(call1.pow1(2, 3))