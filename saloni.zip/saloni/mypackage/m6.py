from mypackage import list1, set2, dict3

print(list1.append1(9))
print(set2.slen2({1,2}))
print(dict3.keys3())