try:
    int('abc')
except ValueError as e:
    print('Error:', e)