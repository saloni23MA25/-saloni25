try:
    x = 5
    x.append(4)
except AttributeError as e:
    print('Error:', e)