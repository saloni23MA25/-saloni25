try:
    x = int('abc')
except (ValueError, ZeroDivisionError, KeyError) as e:
    print('Error:', e)