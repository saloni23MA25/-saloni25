try:
    open('nonexistent.txt')
except FileNotFoundError as e:
    print('Error:', e)