try:
    d = {}
    print(d['key'])
except KeyError as e:
    print('Error:', e)