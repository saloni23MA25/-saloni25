try:
    import non_existing_module
except ModuleNotFoundError as e:
    print('Error:', e)