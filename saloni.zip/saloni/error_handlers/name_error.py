try:
    print(undeclared_variable)
except NameError as e:
    print('Error:', e)